﻿namespace winPEAS._3rdParty.BouncyCastle.asn1
{
    /**
     * basic interface for Der string objects.
     */
    public interface IAsn1String
    {
        string GetString();
    }
}
