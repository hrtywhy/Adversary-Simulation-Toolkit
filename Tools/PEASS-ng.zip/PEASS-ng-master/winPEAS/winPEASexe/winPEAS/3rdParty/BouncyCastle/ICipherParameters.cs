﻿namespace winPEAS._3rdParty.BouncyCastle
{
    public interface ICipherParameters
    {
    }
}
