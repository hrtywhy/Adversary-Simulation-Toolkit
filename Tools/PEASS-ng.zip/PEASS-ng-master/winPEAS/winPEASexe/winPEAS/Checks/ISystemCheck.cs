﻿namespace winPEAS.Checks
{
    internal interface ISystemCheck
    {
        void PrintInfo(bool isDebug);
    }
}
