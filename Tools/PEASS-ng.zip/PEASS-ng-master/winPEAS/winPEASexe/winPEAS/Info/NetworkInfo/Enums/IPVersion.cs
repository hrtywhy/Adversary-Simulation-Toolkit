﻿namespace winPEAS.Info.NetworkInfo.Enums
{
    public enum IPVersion
    {
        IPv4,
        IPv6
    }
}
